

$(document).ready(function () {
    for (let i = 1; i <= 10; i++) {
        $.get('../Pages/quiz.html', function (data) {
            let questionText = $(data).find('#question' + i).text();
            let answerA = $(data).find('label[for="q' + i + 'a"]');
            let answerB = $(data).find('label[for="q' + i + 'b"]');
            let answerC = $(data).find('label[for="q' + i + 'c"]');
            let answerD = $(data).find('label[for="q' + i + 'd"]');
            let answerValA = $(data).find('#q' + i + 'a').val();
            let answerValB = $(data).find('#q' + i + 'b').val();
            let answerValC = $(data).find('#q' + i + 'c').val();
            let answerValD = $(data).find('#q' + i + 'd').val();


            if (answerValA == 'true') {
                $('#edit' + i + 'a').css('background-color', 'green');
            } else if (answerValB == 'true') {
                $('#edit' + i + 'b').css('background-color', 'green');
            } else if (answerValC == 'true') {
                $('#edit' + i + 'c').css('background-color', 'green');
            } else if (answerValD == 'true') {
                $('#edit' + i + 'd').css('background-color', 'green');
            }


            $('#edit' + i).val(questionText);
            $('#edit' + i + 'a').val(answerA.text());
            $('#edit' + i + 'b').val(answerB.text());
            $('#edit' + i + 'c').val(answerC.text());
            $('#edit' + i + 'd').val(answerD.text());
        })
    }

    $('#saveQuestions').click(function () {
        let questions = {};
        for (let i = 1; i <= 10; i++) {

            $('#edit' + i).text();
            $('#edit' + i + 'a').text();
            $('#edit' + i + 'b').text();
            $('#edit' + i + 'c').text();
            $('#edit' + i + 'd').text();

        }

        window.location.href = "../Pages/admin.html";
    })
})