$(document).ready(function () {



    $("#quiz").click(function () {
        window.location.href = "../Pages/quiz.php";
    })

    $("#about").click(function () {
        window.location.href = "../Pages/topic.html";
    })

    $("#highScore").click(function () {
        window.location.href = "../Pages/high_score.html";
    })

    $("#signupBtn").click(function () {
        let adminInfo = {
            'firstName': $('#firstName').val(),
            'lastName': $('#lastName').val(),
            'emailAddress': $('#emailAddress').val(),
            'username': $('#username').val(),
            'password': $('#password').val()
        }

        $.post('../Server/signup.php', adminInfo, function (response) {
            alert(response);
        })
    })

    $('#adminSignup').click(function () {
        window.location.href = "../Pages/signup.html";
    })

    $('#adminLogin').click(function () {
        window.location.href = "../Pages/login.html";
    })

    $('#logoutBtn').click(function () {
        window.location.href = "../Pages/index.html";
    })

    $('#loginBtn').click(function () {
        let loginInfo = {
            'username': $('#usernameLogin').val(),
            'password': $('#passwordLogin').val()
        };
        $.post('../Server/authentication.php', loginInfo, function (response) {
            if (response == 'Success') {
                window.location.href = "../Pages/admin.html";
            } else {
                alert("Incorrect username or password");
            }
        })
    })

    $('#editQuestion').click(function () {
        $('#questionsContainer').load('../Pages/quiz.html');
        for (let i = 1; i <= 10; i++) {
            $('#edit' + i).val($('#question' + i).val());
        }
        window.location.href = "../Pages/edit.html";
    })


})