<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Quiz</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous" />
  <script src="https://code.jquery.com/jquery-3.7.0.min.js"
    integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="../Css/quiz.css" />
  <link rel="stylesheet" href="../Css/styles.css" />

  <style>
    @import url("https://fonts.googleapis.com/css2?family=Russo+One&display=swap");

    * {
      box-sizing: border-box;
      font-family: "Russo One", sans-serif;
    }

    .quiz-container {
      background-color: #424040;
      border-radius: 10px;
      box-shadow: 0 0 10px 2px rgba(100, 100, 100, 0.1);
      width: 600px;
      overflow: hidden;
      margin: auto;
    }

    button {
      background-color: #fc8803;
      color: #fff;
      border: none;
      display: block;
      cursor: pointer;
      font-size: 1rem;
      font-family: inherit;
      padding: 1rem;
      height: auto;
    }

    button:hover {
      background-color: #ff6600;
    }

    button:focus {
      outline: none;
      background-color: #44b927;
    }

    input[type="radio"] {
      margin: 13px;
      justify-content: left;
      align-items: left;
    }

    .card {
      margin: auto;
      background-color: #e6e6e6;
    }
  </style>
</head>

<body>
  <div class="text-center" id="getName">
    <label for="name">Enter your Name</label>
    <input type="text" name="name" id="name" />
    <button id="playQuiz">Play Quiz</button>
  </div>

  <div class="container d-none" id="quizContent">
    <div class="row">
      <div class="col-4"></div>
      <div class="col">
        <h1 class="text-center">Quiz</h1>
      </div>
      <div class="col-4"></div>
    </div>
    <?php include('../Server/update-quiz.php')?>
    <div class="row" id="q1">
      <div class="col-md-6 mx-auto">
        <div class="card shadow rounded-5">
          <div class="card-body p-0">
            <div class="row">
              <div class="col p-5">
                <h3 id='question1' class="text-center">What does PHP stand for?</h3>
                <div>
                  <input type="radio" name="q1Choices" id="q1a" value="false" />
                  <label for="q1a">Personal Hypertext Processor</label>
                </div>
                <div>
                  <input type="radio" name="q1Choices" id="q1b" value="false" />
                  <label for="q1b">Predefined Hypertext Programming</label>
                </div>
                <div>
                  <input type="radio" name="q1Choices" id="q1c" value="true" />
                  <label for="q1c">PHP: Hypertext Preprocessor</label>
                </div>
                <div>
                  <input type="radio" name="q1Choices" id="q1d" value="false" />
                  <label for="q1d">Programming Hypertext Pages</label>
                </div>
              </div>
            </div>
            <div class="card-footer d-grid gap-2 p-0">
              <button id="q1Button">Next</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row d-none" id="q2">
      <div class="col-md-6 mx-auto">
        <div class="card shadow rounded-5">
          <div class="card-body p-0">
            <div class="row">
              <div class="col p-5">
                <h3 id='question2' class="text-center">
                  Question 2: Who originally developed PHP?
                </h3>
                <div>
                  <input type="radio" name="q2Choices" id="q2a" value="false" />
                  <label for="q2a">Microsoft</label>
                </div>
                <div>
                  <input type="radio" name="q2Choices" id="q2b" value="false" />
                  <label for="q2b">Apple</label>
                </div>
                <div>
                  <input type="radio" name="q2Choices" id="q2c" value="true" />
                  <label for="q2c">Rasmus Lerdorf</label>
                </div>
                <div>
                  <input type="radio" name="q2Choices" id="q2d" value="false" />
                  <label for="q2d">Google</label>
                </div>
              </div>
            </div>
            <div class="card-footer d-grid gap-2 p-0">
              <button id="q2Button">Next</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row d-none" id="q3">
      <div class="col-md-6 mx-auto">
        <div class="card shadow rounded-5">
          <div class="card-body p-0">
            <div class="row">
              <div class="col p-5">
                <h3 id='question3' class="text-center">
                  Question 3: What is the correct way to start a PHP script?
                </h3>
                <div>
                  <input type="radio" name="q3Choices" id="q3a" value="false" />
                  <label for="q3a">&lt;php&gt;</label>
                </div>
                <div>
                  <input type="radio" name="q3Choices" id="q3b" value="true" />
                  <label for="q3b">&lt;&quest;php&gt;</label>
                </div>
                <div>
                  <input type="radio" name="q3Choices" id="q3c" value="false" />
                  <label for="q3c">&lcub;php&rcub;</label>
                </div>
                <div>
                  <input type="radio" name="q3Choices" id="q3d" value="false" />
                  <label for="q3d">&lsqb;php&rsqb;</label>
                </div>
              </div>
            </div>
            <div class="card-footer d-grid gap-2 p-0">
              <button id="q3Button">Next</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row d-none" id="q4">
      <div class="col-md-6 mx-auto">
        <div class="card shadow rounded-5">
          <div class="card-body p-0">
            <div class="row">
              <div class="col p-5">
                <h3 id='question4' class="text-center">
                  Question 4: Which symbol is used to comment a single line in
                  PHP?
                </h3>
                <div>
                  <input type="radio" name="q4Choices" id="q4a" value="true" />
                  <label for="q4a">&sol;&sol;</label>
                </div>
                <div>
                  <input type="radio" name="q4Choices" id="q4b" value="false" />
                  <label for="q4b">#</label>
                </div>
                <div>
                  <input type="radio" name="q4Choices" id="q4c" value="false" />
                  <label for="q4c">&sol;*</label>
                </div>
                <div>
                  <input type="radio" name="q4Choices" id="q4d" value="false" />
                  <label for="q4d">&#59;&#59;</label>
                </div>
              </div>
            </div>
            <div class="card-footer d-grid gap-2 p-0">
              <button id="q4Button">Next</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row d-none" id="q5">
      <div class="col-md-6 mx-auto">
        <div class="card shadow rounded-5">
          <div class="card-body p-0">
            <div class="row">
              <div class="col p-5">
                <h3 id='question5' class="text-center">
                  Question 5: Which function is used to output data in PHP?
                </h3>
                <div>
                  <input type="radio" name="q5Choices" id="q5a" value="false" />
                  <label for="q5a">print()</label>
                </div>
                <div>
                  <input type="radio" name="q5Choices" id="q5b" value="false" />
                  <label for="q5b">read()</label>
                </div>
                <div>
                  <input type="radio" name="q5Choices" id="q5c" value="true" />
                  <label for="q5c">echo()</label>
                </div>
                <div>
                  <input type="radio" name="q5Choices" id="q5d" value="false" />
                  <label for="q5d">write()</label>
                </div>
              </div>
            </div>
            <div class="card-footer d-grid gap-2 p-0">
              <button id="q5Button">Next</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row d-none" id="q6">
      <div class="col-md-6 mx-auto">
        <div class="card shadow rounded-5">
          <div class="card-body p-0">
            <div class="row">
              <div class="col p-5">
                <h3 id='question6' class="text-center">
                  Question 6: What is the file extension for PHP files?
                </h3>
                <div>
                  <input type="radio" name="q6Choices" id="q6a" value="true" />
                  <label for="q6a">.php</label>
                </div>
                <div>
                  <input type="radio" name="q6Choices" id="q6b" value="false" />
                  <label for="q6b">.html</label>
                </div>
                <div>
                  <input type="radio" name="q6Choices" id="q6c" value="false" />
                  <label for="q6c">.txt</label>
                </div>
                <div>
                  <input type="radio" name="q6Choices" id="q6d" value="false" />
                  <label for="q6d">.css</label>
                </div>
              </div>
            </div>
            <div class="card-footer d-grid gap-2 p-0">
              <button id="q6Button">Next</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row d-none" id="q7">
      <div class="col-md-6 mx-auto">
        <div class="card shadow rounded-5">
          <div class="card-body p-0">
            <div class="row">
              <div class="col p-5">
                <h3 id='question7' class="text-center">
                  Question 7: Which of the following is a valid PHP variable
                  name?
                </h3>
                <div>
                  <input type="radio" name="q7Choices" id="q7a" value="true" />
                  <label for="q7a">$myVar</label>
                </div>
                <div>
                  <input type="radio" name="q7Choices" id="q7b" value="false" />
                  <label for="q7b">$_variable</label>
                </div>
                <div>
                  <input type="radio" name="q7Choices" id="q7c" value="false" />
                  <label for="q7c">123abc</label>
                </div>
                <div>
                  <input type="radio" name="q7Choices" id="q7d" value="false" />
                  <label for="q7d">$my-var</label>
                </div>
              </div>
            </div>
            <div class="card-footer d-grid gap-2 p-0">
              <button id="q7Button">Next</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row d-none" id="q8">
      <div class="col-md-6 mx-auto">
        <div class="card shadow rounded-5">
          <div class="card-body p-0">
            <div class="row">
              <div class="col p-5">
                <h3 id='question8' class="text-center">
                  Question 8: What is the correct way to include an external
                  PHP file in another PHP file?
                </h3>
                <div>
                  <input type="radio" name="q8Choices" id="q8a" value="false" />
                  <label for="q8a">import 'file.php'&#59;</label>
                </div>
                <div>
                  <input type="radio" name="q8Choices" id="q8b" value="false" />
                  <label for="q8b">require 'file.php'&#59;</label>
                </div>
                <div>
                  <input type="radio" name="q8Choices" id="q8c" value="true" />
                  <label for="q8c">include 'file.php'&#59;</label>
                </div>
                <div>
                  <input type="radio" name="q8Choices" id="q8d" value="false" />
                  <label for="q8d">load 'file.php'&#59;</label>
                </div>
              </div>
            </div>
            <div class="card-footer d-grid gap-2 p-0">
              <button id="q8Button">Next</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row d-none" id="q9">
      <div class="col-md-6 mx-auto">
        <div class="card shadow rounded-5">
          <div class="card-body p-0">
            <div class="row">
              <div class="col p-5">
                <h3 id='question9' class="text-center">
                  Question 9: Which function is used to connect PHP with a
                  MySQL database?
                </h3>
                <div>
                  <input type="radio" name="q9Choices" id="q9a" value="false" />
                  <label for="q9a">mysqli_connect()</label>
                </div>
                <div>
                  <input type="radio" name="q9Choices" id="q9b" value="true" />
                  <label for="q9b">mysql_connect()</label>
                </div>
                <div>
                  <input type="radio" name="q9Choices" id="q9c" value="false" />
                  <label for="q9c">sql_connect()</label>
                </div>
                <div>
                  <input type="radio" name="q9Choices" id="q9d" value="false" />
                  <label for="q9d">load 'file.php'&#59;</label>
                </div>
              </div>
            </div>
            <div class="card-footer d-grid gap-2 p-0">
              <button id="q9Button">Next</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row d-none" id="q10">
      <div class="col-md-6 mx-auto">
        <div class="card shadow rounded-5">
          <div class="card-body p-0">
            <div class="row">
              <div class="col p-5">
                <h3 id='question10' class="text-center">
                  Question 10: Is PHP a server-side scripting language?
                </h3>
                <div>
                  <input type="radio" name="q10Choices" id="q10a" value="true" />
                  <label for="q10a">Yes</label>
                </div>
                <div>
                  <input type="radio" name="q10Choices" id="q10b" value="false" />
                  <label for="q10b">No</label>
                </div>
              </div>
            </div>
            <div class="card-footer d-grid gap-2 p-0">
              <button id="q10Button">Submit</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row d-none" id="q11">
      <div class="col-md-6 mx-auto">
        <div class="card shadow rounded-5">
          <div class="card-body p-0">
            <div class="row">
              <div class="col p-5">
                <h1 class="text-center">Quiz Finish</h1>
                <p>Your score is: <span id="score"></span></p>
                <div class="card-footer d-grid gap-2 p-0">
                  <button id="homeButton">Home</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"
    integrity="sha384-fbbOQedDUMZZ5KreZpsbe1LCZPVmfTnH7ois6mU1QK+m14rQ1l2bGBq41eYeM/fS"
    crossorigin="anonymous"></script>

  <script src="../Javascript/quiz.js"></script>
  <script src="../Javascript/edit.js"></script>
</body>

</html>