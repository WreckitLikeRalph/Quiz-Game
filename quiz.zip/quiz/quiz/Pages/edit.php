<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Questions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous" />
</head>

<body>
    <h1>Edit Questions</h1>

    <div id="editContainer">
        <div>
            <input type="text" id="edit1">
            <input type="text" id="edit1a">
            <input type="text" id="edit1b">
            <input type="text" id="edit1c">
            <input type="text" id="edit1d">
        </div>
        <div>
            <input type="text" id="edit2">
            <input type="text" id="edit2a">
            <input type="text" id="edit2b">
            <input type="text" id="edit2c">
            <input type="text" id="edit2d">
        </div>
        <div>
            <input type="text" id="edit3">
            <input type="text" id="edit3a">
            <input type="text" id="edit3b">
            <input type="text" id="edit3c">
            <input type="text" id="edit3d">
        </div>
        <div>
            <input type="text" id="edit4">
            <input type="text" id="edit4a">
            <input type="text" id="edit4b">
            <input type="text" id="edit4c">
            <input type="text" id="edit4d">
        </div>
        <div>
            <input type="text" id="edit5">
            <input type="text" id="edit5a">
            <input type="text" id="edit5b">
            <input type="text" id="edit5c">
            <input type="text" id="edit5d">
        </div>
        <div>
            <input type="text" id="edit6">
            <input type="text" id="edit6a">
            <input type="text" id="edit6b">
            <input type="text" id="edit6c">
            <input type="text" id="edit6d">
        </div>
        <div>
            <input type="text" id="edit7">
            <input type="text" id="edit7a">
            <input type="text" id="edit7b">
            <input type="text" id="edit7c">
            <input type="text" id="edit7d">
        </div>
        <div>
            <input type="text" id="edit8">
            <input type="text" id="edit8a">
            <input type="text" id="edit8b">
            <input type="text" id="edit8c">
            <input type="text" id="edit8d">
        </div>
        <div>
            <input type="text" id="edit9">
            <input type="text" id="edit9a">
            <input type="text" id="edit9b">
            <input type="text" id="edit9c">
            <input type="text" id="edit9d">
        </div>
        <div>
            <input type="text" id="edit10">
            <input type="text" id="edit10a">
            <input type="text" id="edit10b">
            <input type="text" id="edit10c">
            <input type="text" id="edit10d">
        </div>
        <button id="saveQuestions">Save</button>
    </div>
    <div id='questionsContainer' class="d-none"></div>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"
        integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz"
        crossorigin="anonymous"></script>
    <script src="../Javascript/script.js"></script>
    <script src="../Javascript/edit.js"></script>
</body>

</html>