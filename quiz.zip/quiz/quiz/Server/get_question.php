<?php
include('../Server/connction.php');

$sql = "SELECT * FROM questions";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {

    echo '
<div class="row" id="q'.$row["q_number"].'>
      <div class="col-md-6 mx-auto">
        <div class="card shadow rounded-5">
          <div class="card-body p-0">
            <div class="row">
              <div class="col p-5">
                <h3 id="question'.$row["q_number"].'" class="text-center">'.$row['question'].'</h3>
                <div>
                  <input type="radio" name="q1Choices" id="q1a" value="false" />
                  <label for="q1a">Personal Hypertext Processor</label>
                </div>
                <div>
                  <input type="radio" name="q1Choices" id="q1b" value="false" />
                  <label for="q1b">Predefined Hypertext Programming</label>
                </div>
                <div>
                  <input type="radio" name="q1Choices" id="q1c" value="true" />
                  <label for="q1c">PHP: Hypertext Preprocessor</label>
                </div>
                <div>
                  <input type="radio" name="q1Choices" id="q1d" value="false" />
                  <label for="q1d">Programming Hypertext Pages</label>
                </div>
              </div>
            </div>
            <div class="card-footer d-grid gap-2 p-0">
              <button id="q1Button">Next</button>
            </div>
          </div>
        </div>
      </div>
    </div>

'
  }
} else {
  echo "0 results";
}



$conn->close();
?>
