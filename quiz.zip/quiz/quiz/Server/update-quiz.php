<?php
// Get the modified data from the AJAX request
$modifiedData = $_POST['modifiedData'];

// Specify the path to the quiz.html file
$filePath = '../Pages/quiz.html';

// Update the content of the quiz.html file with the modified data
file_put_contents($filePath, $modifiedData);

// Send a response back to the AJAX request
$response = array('status' => 'success', 'message' => 'Data updated successfully!');
echo json_encode($response);
?>