<?php 
include('connection.php');
$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$emailAddress = $_POST['emailAddress'];
$username = $_POST['username'];
$password = $_POST['password'];

$sql = "INSERT INTO admin (username, password, firstName, lastName, emailAddress)
        VALUES ('$username', '$password', '$firstName', '$lastName', '$emailAddress')";

if ($conn->query($sql) === TRUE) {
    echo "Admin created";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>